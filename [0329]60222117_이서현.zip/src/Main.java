public class Main {
	
	public Main() {
		
	}

	public void run() {
		Calculator calculator = new Calculator();
		calculator.run();
	}
	
	public static void main(String[] args) {
		Main main = new Main();
			main.run();
	}
}