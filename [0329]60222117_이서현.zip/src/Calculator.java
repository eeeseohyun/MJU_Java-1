
import java.io.IOException;

public class Calculator {
	final static int CR = 0x0d;
	final static int Space=0x20;
	final static int Tap=0x09;
	private int readOperator() throws IOException {
		// TODO Auto-generated method stub
		int operator = System.in.read();
		int buffer=System.in.read();
		switch(buffer) {
		case CR:
			System.in.read();
			buffer=0;
			return operator;
		case Space:
			buffer=0;
			return operator;
		case Tap:
			buffer=0;
			return operator;
		default:
			throw new IOException();
		}
		
	}
	
	private int readInt() throws IOException {
		
		int code = System.in.read();
		int number = 0;
		
			while(code >= '0' && code <= '9') {
				number = number * 10 + (code - '0');
				code = System.in.read();
			} 

			switch(code) {
			case CR:
				System.in.read();
				code=0;
				return number;
			case Space:
				code=0;
				return number;
			case Tap:
				code=0;
				return number;
			default:
				throw new IOException();
			}
		}
	
	public int compute(int code) throws IOException {
		int result = 0;
		int input1 = readInt();  
		int input2 = readInt();
		
		if(code == '+') {
			result = input1 + input2;
		} else if(code == '-') {
			result = input1 - input2;
		} else if(code == '*') {
			result = input1 * input2;
		} else if(code == '/') {
			result = input1 / input2;
		}else {
			throw new IOException();
		}
		return result;
	}
	
	public void run() {
		try {
			int code = readOperator();
			while(code!='q') {
			int result = compute(code);
			System.out.println(result);
			code = readOperator();
			}
		} catch (IOException e) {
			e.printStackTrace();
		}
	}
}