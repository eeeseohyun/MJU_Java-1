import java.io.IOException;

public class Calculator {
	public static void main(String[] args) {
		// TODO Auto-generated method stub
	Calculator main = new Calculator();
	while(true) {
		System.out.println("Prefix Notation 연산을 실행합니다. ");
		System.out.println("(연산자:+ - * /)와 숫자를 이용한 prefix식을 입력하세요.");
		main.run();
	}
	}
	static final int cr=0x0d;
	static final int lf=0x0a;
	static final int space = 0x20;
	private float read() throws IOException{
		float code=0;
		float number1=0;
		code=System.in.read();
		if(code>='0' && code<='9') {
			while(code>='0' && code<='9') {
				number1= number1*10+(code -0x30);
				code=System.in.read();
			}
			if(code==space) {
				code=0;
			}
			return number1;
		}else if(code == '+') {
			System.in.read();
			number1=add();
			
		}else if(code== '-') {
			System.in.read();
			number1=subtract();
			
		}else if(code=='*') {
			System.in.read();
			number1=multiply();
			
		}else if(code=='/') {
			System.in.read();
			number1=devide();
			
		}else {
			Calculator main2 = new Calculator();
			main2.run();
		}
		return number1;
	}
	 
	private float add() throws IOException{
		float num1=read();
		float num2=read();
		float sum = num1+num2;
		return sum;
	}
	
	private float multiply() throws IOException{
		float num1=read();
		float num2=read();
		float sum = num1*num2;
		return sum;
	}
	
	private float subtract() throws IOException{
		float num1=read();
		float num2=read();
		float sum = num1-num2;
		return sum;
	}
	
	private float devide() throws IOException{
		float num1= read();
		float num2= read();
		float sum = num1/num2;
		return sum;
	}
	
	public void run() {
		try {
			float code=read();
			System.out.println(code);
			System.in.read();
			
			
		}catch(IOException e) {
			e.printStackTrace();
			System.exit(0);
		}
	}
}

	
	



