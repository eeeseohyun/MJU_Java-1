
import java.io.IOException;

public class Calculator {
	final static int CR = 0x0d;
	final static int Space=0x20;
	final static int Tab=0x09;
	final static int LF =0x10;
	private int readOperator() throws IOException {
		// TODO Auto-generated method stub\
//		int code = System.in.read();
//		while(code==Space || code ==Tab || code==CR || code==LF) {
//			code = System.in.read(); 
//		}
		
		int code = System.in.read();
		while(!(code=='*' || code =='-' || code=='+' || code=='/')) {
			code = System.in.read(); 
		} 
	
		return code;
		}
	
	private int readInt() throws IOException {
		
		int code = System.in.read();
		int number = 0;
			while(!(code >= '0' && code <= '9')) {
				code = System.in.read();
			}
			while(code >= '0' && code <= '9') {
				number = number * 10 + (code - '0');
				code = System.in.read();
			} 
			return number;
				
		}
	
	public int compute(int code) throws IOException {
		int result = 0;
		int input1 = readInt();  
		int input2 = readInt();
		
		if(code == '+') {
			result = input1 + input2;
		} else if(code == '-') {
			result = input1 - input2;
		} else if(code == '*') {
			result = input1 * input2;
		} else if(code == '/') {
			result = input1 / input2;
		}else {
			throw new IOException();
		}
		return result;
	}
	
	public void run() {
		try {
			int code = readOperator();
			while(code!='q') {
			int result = compute(code);
			System.out.println(result);
			code = readOperator();
			}
		} catch (IOException e) {
			e.printStackTrace();
		}
	}
}