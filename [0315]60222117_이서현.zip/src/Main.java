import java.util.Scanner;

public class Main {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		// 아스키코드로 두개의 숫자를 받아 문자열에 각각 저장한다.
		Scanner sc= new Scanner(System.in);
        String str = sc.nextLine();
        String str2= sc.nextLine();
        //각 문자열을 정수로 변환한다.
        long num=0;
        long num2=0;
        long sum=0;
        for(int i=0; i<str.length(); i++) {
        	num+=(str.charAt(i)-'0')*(Math.pow(10,str.length()-i-1));
        }
        for(int i=0; i<str2.length(); i++) {
        	num2+=(str2.charAt(i)-'0')*(Math.pow(10,str2.length()-i-1));
        }
        //두 정수를 합한다.
        sum=num+num2;
        //정수를 다시 문자열로 바꾼다.
        String str3= String.valueOf(sum);
        //최종 출력한다.
        System.out.println(str3);
        
	}

}
