import java.util.Scanner;

public class Main {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
			Scanner sc= new Scanner(System.in);
			// input validation : 정수가 아니면 저장하지 않음 
			if(!sc.hasNextInt()) {
				sc.next();
			}else {
			// 정수면 저장함.
			int num= sc.nextInt();
			// 정수의 자릿수 구하기.
			String strNum=Integer.toString(num);
			// 문자 배열 선언
			char[] Array;
			Array= new char[strNum.length()];
		    // 데이터 저장하기
			for(int i=0; num!=0; i++) {
				Array[i]=(char)((num%10)+'0');
				num=(num/10);
			}
			
			// 16진법으로 바꾸기 
			String result="";
			for(int k=strNum.length()-1; k>=0; k--) {
				//System.out.println(Integer.toBinaryString((int)Array[k]));
				result+= String.format("%02X",  (int)Array[k]);
			}
			// 출력하기
			System.out.println(result);
		}
	}
}


