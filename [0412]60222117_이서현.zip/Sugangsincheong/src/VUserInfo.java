
public class VUserInfo {
	private String name;
	

	public String getName() {
		// TODO Auto-generated method stub
		return name;

	}

	public void setName(String name) {
		this.name = name;
	}
}
