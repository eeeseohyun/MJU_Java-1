import java.util.Scanner;

public class PSugangsincheong {
	static int subjectNum;
	static char answer;
	
	public PSugangsincheong(VUserInfo vUserInfo) {
		// TODO Auto-generated constructor stub
	}

	public void run() {
		
	}

}
