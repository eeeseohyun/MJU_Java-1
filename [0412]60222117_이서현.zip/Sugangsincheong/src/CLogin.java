import java.io.FileNotFoundException;

public class CLogin {

	public VUserInfo login(VLogin vLogin) throws FileNotFoundException {
		// TODO Auto-generated method stub
		MAccount mAccount = new MAccount();
		VUserInfo vUserInfo= mAccount.login(vLogin);
		return vUserInfo;
	}

}
