
public class VLogin {

	private String userId;
	private String password;
	
	public void setUserId(String userId) {
		// TODO Auto-generated method stub
		this.userId = userId;
	}

	public void setPassword(String password) {
		// TODO Auto-generated method stub
		this.password = password;
		
	}

	public String getPassword() {
		// TODO Auto-generated method stub
		return userId;
	}

	public String getUserId() {
		// TODO Auto-generated method stub
		return password;
	}

}
