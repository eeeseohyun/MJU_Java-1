
import java.util.Scanner;
public class Java1_3 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		
		Scanner scan = new Scanner(System.in);
		char cVar=0;
		while((cVar=scan.next().charAt(0))!='x') {
			System.out.println(cVar);		
			}
	}
}

