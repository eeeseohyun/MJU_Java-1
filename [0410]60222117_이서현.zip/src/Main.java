
public class Main {
	private void run() {
		VLogin vLogin =new VLogin();// class도 객체를 만드는 객체임
		if(vLogin.login()==true) {
			VSugangsincheong vSugangsincheong = new VSugangsincheong();
			vSugangsincheong.sugangsincheong();
		}
	 
	}
	public static void main(String[] args) {//시작점을 알려주는 함수
		// TODO Auto-generated method stub
		Main main =new Main();
		main.run();
		
	}

}
