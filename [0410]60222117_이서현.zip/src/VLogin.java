import java.util.Scanner;

public class VLogin {
	
	String userId;
	String userPassward; 
	static int check;
	public boolean login() {
		// TODO Auto-generated method stub
		
		Scanner scanner = new Scanner(System.in);
		
		System.out.println("사용자 아이디를 입력하세요.");
		userId = scanner.next();

		System.out.println("비밀번호를 입력하세요.");
		userPassward = scanner.next();
		
		System.out.println();
		System.out.print("ID : ");
		System.out.println(userId);
		System.out.print("Passward: ");
		System.out.println(userPassward);
		System.out.println();
		System.out.println("입력정보가 맞다면 Y, 그렇지 않다면 N을 입력해주세요.");
		check= scanner.next().charAt(0);
		
		if(check=='Y') {
			System.out.println("로그인이 되었습니다.");
		}else {
			System.out.println("로그인이 취소되었습니다.");
		}
		return true;
		}

}
