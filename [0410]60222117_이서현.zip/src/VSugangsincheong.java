import java.util.Scanner;

public class VSugangsincheong {
	static int subjectNum;
	static char answer;
	
	public void sugangsincheong() {
		// TODO Auto-generated method stub
		Scanner scanner = new Scanner(System.in);
		System.out.println();
		System.out.println("수강희망 과목번호를 입력하세요");
		subjectNum =scanner.nextInt();
		System.out.println();
		System.out.print(subjectNum);
		System.out.println("과목을 수강신청 하시겠습니까?(Y,N을 입력해주세요)");
		answer= scanner.next().charAt(0);
		System.out.println();
		if(answer=='Y') {
			System.out.println("수강신청을 완료했습니다.");
		}else {
			System.out.println("수강신청을 실패했습니다.");
		}
		
		scanner.close();
	}

}
