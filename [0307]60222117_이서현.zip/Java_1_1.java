
public class Java_1_1 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		System.out.println("Hello World!");
		int sum=0;
		for(int i=1; i<11; i++) 
			sum = sum+i;
		
		System.out.print(sum);
	}

}
